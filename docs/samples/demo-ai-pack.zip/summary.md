# Shindan — Araç teşhis raporu

- **Oluşturulma:** 12.10.2026 20:48:29
- **VIN:** `JTDBR32E720012345` — Toyota, 2002, Japan
- **Protokol:** ISO 15765-4 CAN (11 bit, 500 kbaud)
- **Adaptör:** Shindan Demo (ELM327 v1.5)
- **Demo modu: veriler simüle edilmiş bir araçtan.**

## Bulgular

- 🔴 Motor arıza lambası (MIL) yanıyor.
- 🔴 1 kayıtlı arıza kodu: P0301.
- 🟠 1 bekleyen (henüz onaylanmamış) arıza kodu: P0171.
- ℹ️ 2 hazırlık monitörü tamamlanmadı. Araç henüz emisyon muayenesinden geçemeyebilir.

## Arıza

| Kod | Tür | ECU | Açıklama |
|---|---|---|---|
| P0301 | Kayıtlı | 7E8 | 1. silindirde tekleme tespit edildi |
| P0171 | Bekleyen | 7E8 | Sistem çok fakir (Banka 1) |

## Donmuş kare (P0301)

| Sinyal | Değer |
|---|---|
| Motor devri | 812 rpm |
| Araç hızı | 0 km/h |
| Motor soğutma suyu sıcaklığı | 88 °C |
| Hesaplanan motor yükü | 24.31 % |
| Kısa dönem yakıt düzeltmesi — Banka 1 | 2.344 % |
| Uzun dönem yakıt düzeltmesi — Banka 1 | 4.688 % |
| Emme havası sıcaklığı | 27 °C |
| Emme manifoldu basıncı (MAP) | 33 kPa |

## Muayene hazırlığı

- ✅ Tekleme — Hazır
- ✅ Yakıt sistemi — Hazır
- ✅ Kapsamlı bileşenler — Hazır
- ⏳ Katalizör — Hazır değil
- ⏳ Buharlaşma sistemi (EVAP) — Hazır değil
- ✅ Oksijen sensörü — Hazır
- ✅ Oksijen sensörü ısıtıcısı — Hazır
- ✅ EGR / VVT sistemi — Hazır

## Kayıt

- **Süre:** 8.22 s
- **Örnek:** 140
- **Şablon:** Günlük sürüş

| Sinyal | Birim | En düşük | Ortalama | En yüksek | p95 | n | Tipik sağlıklı aralık |
|---|---|---|---|---|---|---|---|
| Motor devri (`rpm`) | rpm | 779.5 | 790.2 | 800.75 | 800 | 21 |  |
| Araç hızı (`speed`) | km/h | 0 | 0 | 0 | 0 | 21 |  |
| Hesaplanan motor yükü (`engineLoad`) | % | 21.57 | 22 | 22.35 | 22.35 | 21 |  |
| Gaz kelebeği konumu (`throttle`) | % | 14.51 | 14.51 | 14.51 | 14.51 | 21 |  |
| Motor soğutma suyu sıcaklığı (`coolantTemp`) | °C | 36 | 39 | 42 | 41.7 | 3 | 75–105 |
| Emme havası sıcaklığı (`intakeTemp`) | °C | 30 | 30 | 30 | 30 | 2 |  |
| Hava akış oranı (MAF) (`maf`) | g/s | 4.36 | 4.4415 | 4.55 | 4.531 | 20 |  |
| Kısa dönem yakıt düzeltmesi — Banka 1 (`stftB1`) | % | 0 | 0 | 0 | 0 | 20 | -10–10 |
| Uzun dönem yakıt düzeltmesi — Banka 1 (`ltftB1`) | % | 4.688 | 4.688 | 4.688 | 4.688 | 7 | -10–10 |
| Yakıt seviyesi (`fuelLevel`) | % | 62.35 | 62.35 | 62.35 | 62.35 | 2 |  |
| Kontrol modülü voltajı (`moduleVoltage`) | V | 14.172 | 14.187 | 14.202 | 14.2005 | 2 | 12.2–14.8 |

## İşaretler

- **4.081 s** — Gaz pedalında tekleme  
  `rpm=799, speed=0, engineLoad=21.96, throttle=14.51, coolantTemp=36, intakeTemp=30, maf=4.4, stftB1=0`
