# Shindan data pack — read me first

This archive contains OBD-II diagnostic data from one vehicle, captured in a web browser by **Shindan**
through an ELM327-compatible Bluetooth adapter. It is designed to be analysed by people and by AI assistants.

## Files
| File | What it is |
|---|---|
| `summary.md` | Human-readable summary: findings, fault codes, readiness, statistics, markers. Start here. |
| `session.json` | Complete structured data (schema `shindan.session/v1`): vehicle, adapter, DTCs with descriptions, readiness, freeze frame, per-signal metadata and statistics, and the full time series. |
| `samples_long.csv` | Every reading, one per row: `t_ms, iso_time, signal, value, unit`. Lossless. |
| `timeline.csv` | All signals aligned on a 0.5 s grid (latest value, blank if stale). Convenient for correlation and spreadsheets. |

## Conventions
- Values are in base units: km/h, °C, kPa, g/s, L/h, V, %, rpm, λ (lambda), s, km.
- `t_ms` is milliseconds since the start of the recording. Signals are polled round-robin, so they are **not**
  sampled at the same instants; fast signals (rpm, speed, load) update more often than slow ones (temperatures).
- `markers` are moments the driver flagged, often with a note describing a symptom. `valuesAtMarker` gives the
  latest reading of each signal at that moment.
- `connectionEvents` explain gaps (adapter link paused/resumed).
- Fuel trims: positive = ECU adding fuel (lean condition), negative = removing fuel (rich). |STFT+LTFT| > 10 % is notable.
- `findings` are conservative rule-based observations, not a diagnosis.

> **Note:** this pack was generated in demo mode from a simulated vehicle.

## Suggested prompt
"Here is OBD-II data from my car (Shindan data pack). Read README.md and summary.md, then analyse session.json.
Explain any fault codes, check whether sensor values are plausible and consistent with each other, relate the
markers to the data, and list the most likely causes and what to check first."
